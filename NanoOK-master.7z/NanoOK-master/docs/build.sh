/usr/local/Cellar/sphinx-doc/1.7.9/bin/sphinx-build -a -b html source build

#pandoc --from html --to rst datafiles.html > source/datafiles.rst

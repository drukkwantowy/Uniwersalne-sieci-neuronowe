# echo "Turn the EXT PWR dip Switch to OFF"
# read -p "Press enter to continue... "
echo "Starting functional testing..."
node test/js/qc.js

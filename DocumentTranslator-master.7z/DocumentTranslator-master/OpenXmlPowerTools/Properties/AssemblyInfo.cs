﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("OpenXmlPowerTools.Tests")]

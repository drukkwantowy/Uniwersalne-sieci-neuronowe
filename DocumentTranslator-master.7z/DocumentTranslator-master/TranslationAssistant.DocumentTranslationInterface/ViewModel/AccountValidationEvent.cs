﻿using Microsoft.Practices.Prism.Events;

namespace TranslationAssistant.DocumentTranslationInterface.Common
{
    internal class AccountValidationEvent : CompositePresentationEvent<bool>
    {
    }
}

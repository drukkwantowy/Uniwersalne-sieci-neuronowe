# My Story
The men were *stopped* before **boarding** the flight
to Newark, New Jersey on Saturday **morning**.

Both were arrested on _suspicion_ of being
under the influence of drink or __drugs__.

The flight was scheduled for 9am but
it was cancelled following the pair’s arrest.

“Police Scotland can confirm that two men aged 61 and 45 years old have been arrested
and remanded in custody pending a scheduled court appearance on Tuesday August 6 on
suspicion of offences under the Railways and Transport Safety Act 2003, section 97,”
a spokesperson said.

The act covers offences where pilots are found to be intoxicated.

##Penalty
If found guilty under the law, the pilots could face a fine or
up to two years in prison.

The limit for alcohol in the breath for pilots is 9 microgrammes
per 100mm.

The US Federal Aviation Industry also has an eight-hour “bottle to throttle”
rule, which bans pilots from flying within eight hours of drinking.

### Lists
* Item 1
* Item 2
  * Item 2a
  * Item 2b
  
 ### Links
 [GitHub](http://github.com)

### Blockquotes
As Kanye West said:

> We're living the future so
> the present is our past.

### Inline Code
I think you should use an
`<addr>` element here instead.

### Strikethrough
This is ~~stricken through~~.

### Code sections
```
Open()
Close()
```

###Task Lists
- [x] @mentions, #refs, [links](), **formatting**, and <del>tags</del> supported
- [x] list syntax required (any unordered or ordered list supported)
- [x] this is a complete item
- [ ] this is an incomplete item for #Tian500

### Table
This is a | Header
----------| -------
We have | no steam

The cells of the table should be translated as individual sentences.


